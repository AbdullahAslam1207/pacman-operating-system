#include <SFML/Graphics.hpp>
#include <SFML/Audio.hpp>
#include <chrono>
#include <ctime>
#include <pthread.h>
#include <X11/Xlib.h>
#include<iostream>
#include<unistd.h>
#include<fstream>
#include<sstream>
#include <semaphore.h>
using namespace sf;
using namespace std;
#define N 4
#define THINKING 2
#define HUNGRY 1
#define EATING 0
#define LEFT (phnum + 3) % N
#define RIGHT (phnum + 1) % N
int state[N];
bool ate[N]={false};

int phil[N] = { 0, 1, 2, 3};


const int CELL_SIZE = 16;
const int FONT_HEIGHT = 16;
const int MAP_HEIGHT = 21;
const int MAP_WIDTH = 21;
const int SCREEN_RESIZE = 2;
const int FRAME_DURATION = 16667;
int totalpellets=0;
int powerpellet=0;
pthread_mutex_t mutex;
sem_t semaphore,semaphore2,semaphore3,semaphore4;
sem_t kp[4];

//dining philsphers sem and mut
pthread_mutex_t mutex1, phil_mutex;
sem_t forks[N]; 
int key=2;
int permit=2;


struct Ghost{
    Texture tex;
    Sprite sprite;
    float x,y;
    float xPos,yPos;
    int prev_direction;
    float speed;
    bool house;
    bool random;
    int count;
    bool moveout;
    bool set;
    Clock clock;
    bool escaped;
    bool pickup;
    bool keypickup;
    bool permitpickup;
    int direction;
    bool fastghost;
    bool eaten;
    Clock fasttimer;
Ghost(std::string png_path){
    tex.loadFromFile(png_path);
    sprite.setTexture(tex);
    x=10*CELL_SIZE;
    y=9*CELL_SIZE;
    xPos=10*CELL_SIZE;
    yPos=9*CELL_SIZE;
    sprite.setPosition(x,y);
    sprite.setScale(0.25,0.25);
    prev_direction = -1;
    speed=0.01;
    house=1;
    random=1;
    count=0;
    moveout=0;
    set=0;
    escaped=false;
    pickup=0;
    keypickup=0;
    permitpickup=0;
    fastghost=0;
    eaten=0;
}
void start() 
{
    fasttimer.restart(); // Start the clock
}
bool checktime()
{
    bool val=0;
    if (fasttimer.getElapsedTime().asSeconds()>8)
    {
        val=1;
        
    }
    return val;
}
void resetvariables(){
    // pickup=0;
    // keypickup=0;
    // permitpickup=0;
    count=0;
    moveout=0;
    house=1;
    escaped=false;
    random=0;
}

void changeimage(string png_path)
{
    tex.loadFromFile(png_path);
    sprite.setTexture(tex);
    sprite.setScale(0.25,0.25);
}
};



struct Permit{
    Texture tex;
    Sprite sprite;
    float x,y;
    bool spawn;
    Permit(string png_path){
        tex.loadFromFile(png_path);
        sprite.setTexture(tex);
        x=11*CELL_SIZE;
        y=9*CELL_SIZE;
        sprite.setPosition(x,y);
        sprite.setScale(0.02,0.02);
        spawn=0;
    }

};
struct Key{
    Texture tex;
    Sprite sprite;
    float x,y;
    bool spawn;
    Key(string png_path){
        tex.loadFromFile(png_path);
        sprite.setTexture(tex);
        x=9*CELL_SIZE;
        y=9*CELL_SIZE;
        sprite.setPosition(x,y);
        sprite.setScale(0.025,0.025);
        spawn=0;
    }

};



char map_sketch[MAP_HEIGHT][MAP_WIDTH + 1] = {
        "#####################",
        "#         #         #",
        "#  ## ### # ### ##  #",
        "#                   #",
        "#  ## # ##### # ##  #",
        "#  P  #   #   #     #",
        "####  F       F #####",
        "$$$# ########## #$$$$",
        "#### #$$$$$$$$# #####",
        "$$$  #$$$$$$$$#  $$$$",
        "#### #$$$$$$$$# #####",
        "$$$# #$$$$$$$$# #$$$$",
        "#### ########## #####",
        "#         #         #",
        "#  ## ### # ### ##  #",
        "#   #           #   #",
        "##  # # ##### # #  ##",
        "#     #   #   #     #",
        "#  ###### # ######  #",
        "#                   #",
        "#####################"
    };




//structure for pacman 
struct Pacman
{
    float x, y;
    float speed = 0.1;
    //CircleShape circle;
    char movement;
    char pmove;
    Texture tex;
    Sprite sprite;
    int score;
    int lives;
    bool powercheck;
    Pacman(std::string png_path){
        tex.loadFromFile(png_path);
        sprite.setTexture(tex);
        x = 3*CELL_SIZE, y = 5*CELL_SIZE;
        sprite.setPosition(x, y);
        sprite.setScale(0.27,0.27);
        score=0;
        lives=3;
        powercheck=false;
    }
    void changesprite(string path)
    {
        tex.loadFromFile(path);
        sprite.setTexture(tex);
    }
    void draw(RenderWindow &window)
    {
        window.draw(sprite);
    }
    void leftRotate(){
        sprite.rotate(-90);
    }
    void downRotate(){
         sprite.rotate(180);
    }
    void upRotate(){
         sprite.rotate(-180);
    }
    void RightRotate(){
        sprite.rotate(90);
    }
    void move(std::string s)
    {
        float delta_x = 0, delta_y = 0;
        if (s == "l")
        {
            delta_x = -1;
            changesprite("Resources/pacmanleft.png");
            //leftRotate();
        }
        else if (s == "r")
        {
            changesprite("Resources/pacman.png");
            delta_x = +1;
            //RightRotate();
        }
        else if (s == "u")
        {
            changesprite("Resources/pacmanup.png");
            delta_y = -1;
            //upRotate();
        }
        else if (s == "d")
        {
            changesprite("Resources/pacmandown.png");
            delta_y = 1;
            //downRotate();
        }
        delta_x *= speed;
        delta_y *= speed;
        float temp_x=x;
        float temp_y=y;
        ////cout<<temp_x<<" "<<temp_y<<endl;
        x+=delta_x;
        y+=delta_y;
        if (x < 0)
        {
            x = MAP_WIDTH * CELL_SIZE; // Wrap to the right edge
            sprite.setPosition(x,y);
        }
        else if (x >= MAP_WIDTH * CELL_SIZE){
            x = 0; 
            sprite.setPosition(x,y);

        }
        else
        {
        sprite.move(delta_x, delta_y);
        }
        
    }
    bool checkplayercollision(string s)
    {
        float delta_x = 0, delta_y = 0;
        float nx,ny;
        if (s == "l")
        {
            delta_x = -1;
        }
        else if (s == "r")
        {
            delta_x = +1;
        }
        else if (s == "u")
        {
            delta_y = -1;
        }
        else if (s == "d")
        {
            delta_y = 1;
        }
        nx = x + delta_x * (sprite.getScale().x-0.17) * CELL_SIZE;
        ny = y + delta_y * (sprite.getScale().y-0.17) * CELL_SIZE;
        sf::FloatRect gBound = sprite.getGlobalBounds();
        gBound.left = nx;
        gBound.top = ny;
        ////cout<<pacmanBounds<<endl;
        bool collision=false;
        for (int i = 0; i < MAP_HEIGHT; ++i) 
        {
                for (int j = 0; j < MAP_WIDTH; ++j) {
                    if (map_sketch[i][j] == '#') {
                        sf::RectangleShape wall(sf::Vector2f(CELL_SIZE, CELL_SIZE));
                        wall.setPosition(j * CELL_SIZE, i * CELL_SIZE);
                        sf::FloatRect wallBounds = wall.getGlobalBounds();
                        if (gBound.intersects(wallBounds)) {
                            collision = true;
                            break;
                        }
                    }
                }
                if (collision)
                    break;
        }
        return collision;
    }
};
// Structure to hold pacman and window
struct FastPellet{
    sf::Texture ptex;
    sf::Sprite psprite;
    sf::Texture powertex;
    sf::Sprite powersprite;
FastPellet(){
    ptex.loadFromFile("Resources/pellet.png");
    psprite.setTexture(ptex);
    psprite.setScale(0.27,0.27);
    powertex.loadFromFile("Resources/powerpellet.png");
    powersprite.setTexture(powertex);
    powersprite.setScale(0.27,0.27);
}
};
// Structure to hold pacman and window
struct RenderData {
    //char map[MAP_HEIGHT][MAP_WIDTH];
    sf::RenderWindow* window;
    Pacman* pacman;
    Ghost* ghost;
    Ghost* ghost2;
    Ghost* ghost3;
    Ghost* ghost4;
    Permit* p1;
    Permit* p2;
    Key* k1;
    Key* k2;
    FastPellet* fp1;

    //bool* isWindowOpen;
};




void draw_map(sf::RenderWindow& i_window,FastPellet& p)
{
    sf::RectangleShape cell_shape(sf::Vector2f(CELL_SIZE, CELL_SIZE));
    sf::CircleShape pellet(CELL_SIZE/4.5);
    //sf::CircleShape powerpellet(CELL_SIZE/4.5);
    sf::CircleShape fastpellet(CELL_SIZE/4.5);

    for (int a = 0; a < MAP_WIDTH; a++)
    {
        for (int b = 0; b < MAP_HEIGHT; b++)
        {
            cell_shape.setPosition(static_cast<float>(CELL_SIZE * a), static_cast<float>(CELL_SIZE * b));
            pellet.setPosition(static_cast<float>(CELL_SIZE * a)+3.5, static_cast<float>(CELL_SIZE * b)+3.5);
            p.powersprite.setPosition(static_cast<float>(CELL_SIZE * a)+3.5, static_cast<float>(CELL_SIZE * b)+3.5);
            fastpellet.setPosition(static_cast<float>(CELL_SIZE * a)+3.5, static_cast<float>(CELL_SIZE * b)+3.5);
            p.psprite.setPosition(static_cast<float>(CELL_SIZE * a)+3.5, static_cast<float>(CELL_SIZE * b)+3.5);
            // We just crop out what we need from the texture.
            switch (map_sketch[b][a])
            {
            case '#':
                cell_shape.setFillColor(sf::Color(36, 36, 255));
                i_window.draw(cell_shape);
                break;
            case 'C':
                pellet.setFillColor(sf::Color(255,255,71));
                i_window.draw(pellet);
                break;
            case 'B'://for drawing the pacman power up pellets 
                //powerpellet.setFillColor(sf::Color(255,0,0));
                i_window.draw(p.powersprite);
                break;
             case 'F':
                //fastpellet.setFillColor(sf::Color::White);
                i_window.draw(p.psprite);
                break;

            }

           

        }
    }
}


bool checkfastpelletcollision(Ghost& ghost,FastPellet& p)
{
        float nx,ny;
        nx = ghost.x + (ghost.sprite.getScale().x) * CELL_SIZE;
        ny = ghost.y + (ghost.sprite.getScale().y) * CELL_SIZE;
        sf::FloatRect gBound = ghost.sprite.getGlobalBounds();
        gBound.left = nx;
        gBound.top = ny;
        ////cout<<pacmanBounds<<endl;
        //sf::CircleShape pellet(CELL_SIZE/4.5);

        

        bool collision=false;
        for (int i = 0; i < MAP_HEIGHT; ++i) 
        {
                for (int j = 0; j < MAP_WIDTH; ++j) {
                    if (map_sketch[j][i] == 'F') {
                        p.psprite.setPosition(static_cast<float>(CELL_SIZE * i)+3.5, static_cast<float>(CELL_SIZE * j)+3.5);
                        sf::FloatRect fpelletbounds = p.psprite.getGlobalBounds();
                        if (gBound.intersects(fpelletbounds)) 
                        {
                            //<<"collision with fast pellet"<<endl;
                            collision = true;
                            break;
                        }
                    }
                }
                if (collision)
                    break;
        }
        return collision;

}
bool isValidPosition(int x, int y)
{
    return (map_sketch[y][x] == ' ');
}
void generatepellets()
{
    //cout<<"Generating"<<endl;
   sf::CircleShape pellet(CELL_SIZE/6);   
   while (totalpellets<30)
   {
        int x=rand()%MAP_WIDTH;
        int y=rand()%MAP_WIDTH;
        if (isValidPosition(x,y))
        {
            map_sketch[y][x]='C';
            totalpellets++;
        }

   }
}

void checkcoincollision(Pacman* p){
    float nx,ny;
        nx = p->x + (p->sprite.getScale().x-0.17) * CELL_SIZE;
        ny = p->y + (p->sprite.getScale().y-0.17) * CELL_SIZE;
        sf::FloatRect gBound = p->sprite.getGlobalBounds();
        gBound.left = nx;
        gBound.top = ny;
        ////cout<<pacmanBounds<<endl;
        bool collision=false;
        for (int i = 0; i < MAP_HEIGHT; ++i) 
        {
                for (int j = 0; j < MAP_WIDTH; ++j) {
                    if (map_sketch[j][i] == 'C') {
                        sf::CircleShape pellet(CELL_SIZE/4.5);
                        pellet.setPosition(static_cast<float>(CELL_SIZE * i)+3.5, static_cast<float>(CELL_SIZE * j)+3.5);
                        sf::FloatRect coinbounds = pellet.getGlobalBounds();
                        if (gBound.intersects(coinbounds)) {
                            //cout<<"collision"<<endl;
                            collision = true;
                            map_sketch[j][i]=' ';
                            totalpellets--;
                            p->score+=5;
                           // cout<<"Total pellets:"<<totalpellets<<endl;
                            break;
                        }
                    }
                }
                if (collision)
                    break;
        }
}

void generatepowerpellets()
{
    //cout<<"Generating"<<endl;
   sf::CircleShape pellet(CELL_SIZE/6); 
   //cout<<"power pellet generating"<<endl;  
   while (powerpellet<1)
   {
        int x=rand()%MAP_WIDTH;
        int y=rand()%MAP_WIDTH;
        if (isValidPosition(x,y))
        {
            map_sketch[y][x]='B';
            powerpellet++;
            //cout<<"power pellet generated "<<endl;
        }

   }
}

void checkpowerpelletcollision(Pacman* p,FastPellet& fp){
        float nx,ny;
        nx = p->x + (p->sprite.getScale().x-0.17) * CELL_SIZE;
        ny = p->y + (p->sprite.getScale().y-0.17) * CELL_SIZE;
        sf::FloatRect gBound = p->sprite.getGlobalBounds();
        gBound.left = nx;
        gBound.top = ny;
        ////cout<<pacmanBounds<<endl;
        bool collision=false;
        for (int i = 0; i < MAP_HEIGHT; ++i) 
        {
                for (int j = 0; j < MAP_WIDTH; ++j) {
                    if (map_sketch[j][i] == 'B') {
                        fp.powersprite.setPosition(static_cast<float>(CELL_SIZE * i)+3.5, static_cast<float>(CELL_SIZE * j)+3.5);
                        sf::FloatRect coinbounds = fp.powersprite.getGlobalBounds();
                        if (gBound.intersects(coinbounds)) {
                            //cout<<"collision"<<endl;
                            collision = true;
                            map_sketch[j][i]=' ';
                            powerpellet--;
                            //cout<<"power pellet collison"<<endl;
                            p->powercheck=true;// activate check
                            //p->score+=5;
                            //cout<<"Total pellets:"<<totalpellets<<endl;
                            break;
                        }
                    }
                }
                if (collision)
                    break;
        }
        //return collision;
}


void setinitialPosition(Ghost* g1,Ghost* g2,Ghost* g3,Ghost* g4)
{

    g1->x=10*CELL_SIZE;
    g1->y=9*CELL_SIZE;
    g1->xPos=10*CELL_SIZE;
    g1->yPos=9*CELL_SIZE;
    g1->sprite.setPosition(g2->x,g2->y);

    
    g2->x=9*CELL_SIZE;
    g2->y=10*CELL_SIZE;
    g2->xPos=9*CELL_SIZE;
    g2->yPos=10*CELL_SIZE;

    g2->sprite.setPosition(g2->x,g2->y);

    g3->x=10*CELL_SIZE;
    g3->y=11*CELL_SIZE;
    g3->xPos=10*CELL_SIZE;
    g3->yPos=11*CELL_SIZE;
    g3->sprite.setPosition(g3->x,g3->y);
    

    g4->x=11*CELL_SIZE;
    g4->y=10*CELL_SIZE;
    g4->xPos=11*CELL_SIZE;
    g4->yPos=10*CELL_SIZE;
    g4->sprite.setPosition(g4->x,g4->y);


}

//dining philosphers
void test(int phnum,Ghost* g,Ghost* g1,Ghost* g2,Ghost* g3,Ghost* g4) {
    
    //cout<<state[LEFT]<<" "<<state[RIGHT]<<endl;
    if (state[phnum] == HUNGRY && state[LEFT] != EATING && state[RIGHT] != EATING && key>0 && permit>0 && !ate[phnum]) {
        // state that eating
        
        state[phnum] = EATING;
        //usleep(2000);

        //cout << "Philosopher " << phnum + 1 << " takes fork " << LEFT + 1 << " and " << phnum + 1 << endl;
        //cout << "Philosopher " << phnum + 1 << " is Eating" << endl;
        key--;
        permit--;
        //g->speed=0;
        ate[phnum]=true;
        float delta_x=1;
        float delta_y=0;
        // for (int i=0;i<5;i++)
        // {
        //     cout<<"hello"<<endl;
        //     g->sprite.move(delta_x*g->speed, delta_y*g->speed);
        //     g->x = g->x+(g->speed*delta_x);
        //     g->y = g->y+(g->speed*delta_y);
        // }
        pthread_mutex_lock(&phil_mutex);

        float x=15*CELL_SIZE;
        float y=9*CELL_SIZE;
        float dx=x;
        float dy=y;
        //10 6
        //if (key==2 && permit==2)
        //{

         g->moveout=1;


        //}
        // else 
        // {

        //     x=10*CELL_SIZE;
        //     y=6*CELL_SIZE;
        //     dx=x;
        //     dy=y;
        //     delta_x=0;
        //     delta_y=-1;

        //     while (g->y>=dy)// && g->y<=dy)
        //     {
        //         g->speed=0.00001; 
        //         g->sprite.move(delta_x*g->speed, delta_y*g->speed);
        //         g->x = g->x+(g->speed*delta_x);
        //         g->y = g->y+(g->speed*delta_y);

        //     }
        // }
        //cout<<"reached"<<endl;
        g->house=0;
        if (g->eaten)
            g->speed=0.09;
        else
            g->speed=0.01;
        g->escaped=true;
        if (key==0)
        {
            //cout<<"key 0 hogayi hai"<<endl;
            // g1->house=0;
            // g2->house=0;
            // g3->house=0;
            // g4->house=0;
            if (!g1->escaped )
                g1->random=1;
            if (!g2->escaped )
                g2->random=1;
            if (!g3->escaped )
                g3->random=1;
            if (!g4->escaped )
                g4->random=1;
            g1->speed=0.01;
            g2->speed=0.01;
            g3->speed=0.01;
            g4->speed=0.01;
            if (g1->eaten)
                g1->speed=0.09;
            if (g2->eaten)
                g2->speed=0.09;
            if (g3->eaten)
                g3->speed=0.09;
            if (g4->eaten)
                g4->speed=0.09;

        }
        pthread_mutex_unlock(&phil_mutex);
        //g->sprite.setPosition(x,y);

        //sleep(1);
        
    }
    
}

// take up chopsticks
void take_fork(int phnum,Ghost* g,Ghost* g1,Ghost* g2,Ghost* g3,Ghost* g4) {
    pthread_mutex_lock(&mutex1);

    // state that hungry
    state[phnum] = HUNGRY;

    //cout << "Philosopher " << phnum + 1 << " is Hungry" << endl;

    // eat if neighbors are not eating
    test(phnum,g,g1,g2,g3,g4);

    pthread_mutex_unlock(&mutex1);

    // if unable to eat wait to acquire forks
    int value;
    sem_getvalue(&forks[phnum],&value);
    //cout<<value<<endl;
    sem_wait(&forks[phnum]);
    //cout<<"here"<<endl;
    
    //usleep(1000);
}

// put down chopsticks
void put_fork(int phnum,Ghost* g,Ghost* g1,Ghost* g2,Ghost* g3,Ghost* g4) {
    pthread_mutex_lock(&mutex1);

    // state that thinking
    state[phnum] = THINKING;

    //cout << "Philosopher " << phnum + 1 << " putting fork " << LEFT + 1 << " and " << phnum + 1 << " down" << endl;
    //cout << "Philosopher " << phnum + 1 << " is thinking" << endl;
    if (key>0 && permit>0)
    {

        if (LEFT==3 && RIGHT==1)
        {
            test(LEFT,g4,g1,g2,g3,g4);
            test(RIGHT,g2,g1,g2,g3,g4);
        }
        else if (LEFT==0 && RIGHT==2)
        {
            test(LEFT,g1,g1,g2,g3,g4);
            test(RIGHT,g3,g1,g2,g3,g4);
        }
        else if (LEFT==1 && RIGHT==3)
        {
            test(LEFT,g2,g1,g2,g3,g4);
            test(RIGHT,g4,g1,g2,g3,g4);
        }
        else if (LEFT==2 && RIGHT==0)
        {
            test(LEFT,g3,g1,g2,g3,g4);
            test(RIGHT,g1,g1,g2,g3,g4);
        }
        
    }

    pthread_mutex_unlock(&mutex1);

    // signal the neighbors
    sem_post(&forks[LEFT]);
    sem_post(&forks[RIGHT]);
}

void* philosopher(int num,Ghost** g,Ghost** g1,Ghost** g2,Ghost** g3,Ghost** g4) {
    //while (true) {
        if (key>0 && permit>0)
        {
            int i = num;
            take_fork(i,*g,*g1,*g2,*g3,*g4);
            
            put_fork(i,*g,*g1,*g2,*g3,*g4);
        }
    //}
    return nullptr;
}




bool checkwallghostcollision(sf::FloatRect ghostBounds){
    bool collision=false;
    for (int i = 0; i < MAP_HEIGHT; ++i) 
    {
                for (int j = 0; j < MAP_WIDTH; ++j) {
                     //sem_wait(&sem2);
                    if (map_sketch[i][j] == '#') {
                        sf::RectangleShape wall(sf::Vector2f(CELL_SIZE, CELL_SIZE));
                        wall.setPosition(j * CELL_SIZE, i * CELL_SIZE);
                        sf::FloatRect wallBounds = wall.getGlobalBounds();
                        if (ghostBounds.intersects(wallBounds)) {
                            collision = true;
                            ////cout<<wallBounds.left<<" "<<wallBounds.top<<endl;
                            break;
                        }
                    }
                }
                if (collision)
                    break;
                //sem_post(&sem2);
        }
        return collision;

}
bool checkwallghostcollision2(sf::FloatRect ghostBounds,float boundary){
    bool collision=false;
    for (int i = 0; i < MAP_HEIGHT; ++i) 
        {
                for (int j = 0; j < MAP_WIDTH; ++j) {
                     //sem_wait(&sem2);
                    if (map_sketch[i][j] == '#') {
                        sf::RectangleShape wall(sf::Vector2f(CELL_SIZE, CELL_SIZE));
                        wall.setPosition(j * CELL_SIZE, i * CELL_SIZE);
                        sf::FloatRect wallBounds = wall.getGlobalBounds();
                        if (ghostBounds.intersects(wallBounds) || ghostBounds.left>boundary*CELL_SIZE) {
                            collision = true;
                            ////cout<<wallBounds.left<<" "<<wallBounds.top<<endl;
                            break;
                        }
                    }
                }
                if (collision)
                    break;
                //sem_post(&sem2);
        }
    return collision;
}
void move(Ghost* g, string m){
        float delta_x=0,delta_y=0;
        if (m=="l"){
            delta_x=-1;
        }
        else if (m=="r"){
            delta_x=1;
        }
        else if (m=="u"){
            delta_y=-1;
        }
        else if (m=="d"){
            delta_y=1;
        }
        g->sprite.move(delta_x*g->speed, delta_y*g->speed);
        g->x = g->x+(g->speed*delta_x);
        g->y = g->y+(g->speed*delta_y);
}
bool checksmartcollision(string m,Ghost* g)
{
        float delta_x=0,delta_y=0;
        if (m=="l"){
            delta_x=-1;
        }
        else if (m=="r"){
            delta_x=1;
        }
        else if (m=="u"){
            delta_y=-1;
        }
        else if (m=="d"){
            delta_y=1;
        }
        float nx,ny;
        nx = g->x + delta_x * (g->sprite.getScale().x) * CELL_SIZE;
        ny = g->y + delta_y * (g->sprite.getScale().y) * CELL_SIZE;
        sf::FloatRect gBound = g->sprite.getGlobalBounds();
        gBound.left = nx;
        gBound.top = ny;
        bool collide=false;
        collide=checkwallghostcollision(gBound);
        return collide;
}

void moverandom(Ghost* ghost,int& prev_direction,int id){
        float boundary;
        float delta_x = 0, delta_y = 0;
        int direction;
        int x=0,y=0;
        float nx,ny;
        if (prev_direction==0)
        {
            x=-1;
        }
        if (prev_direction==1)
        {
            x=1;
        }
        if (prev_direction==2)
        {
            y=-1;
        }
        else if (prev_direction==3)
        {
            y=1;
        }
        if (prev_direction==2 || prev_direction==3)
        {
            boundary=8;
            nx = ghost->x + x * ghost->sprite.getScale().x * CELL_SIZE;
            ny = ghost->y + y * ghost->sprite.getScale().y * CELL_SIZE;
            sf::FloatRect gBound = ghost->sprite.getGlobalBounds();
            gBound.left = nx;
            gBound.top = ny;
            bool collide=false;
            collide=checkwallghostcollision(gBound);
            if (collide)
            {
                nx = ghost->x + x * ghost->sprite.getScale().x * CELL_SIZE;
                ny = ghost->y + y * ghost->sprite.getScale().y * CELL_SIZE;
                sf::FloatRect gBound = ghost->sprite.getGlobalBounds();
                gBound.left = nx;
                gBound.top = ny;
                if (prev_direction==3){
                    prev_direction=2;
                }
                else if (prev_direction==2){
                    prev_direction=3;
                }

            }
            ghost->sprite.move(x*ghost->speed, y*ghost->speed);
            ghost->x = ghost->x+(ghost->speed*x);
            ghost->y = ghost->y+(ghost->speed*y);
        }
        else
        {
            nx = ghost->x + x * ghost->sprite.getScale().x * CELL_SIZE;
            ny = ghost->y + y * ghost->sprite.getScale().y * CELL_SIZE;
            sf::FloatRect gBound = ghost->sprite.getGlobalBounds();
            gBound.left = nx;
            gBound.top = ny;
            bool collide=false;
            collide=checkwallghostcollision(gBound);
            if (collide)
            {
                bool collision=false;
                sf::FloatRect ghostBounds = ghost->sprite.getGlobalBounds();
                ghostBounds.left = nx;
                ghostBounds.top = ny;
                if (prev_direction==0){
                    prev_direction=1;
                }
                else if (prev_direction==1){
                    prev_direction=0;
                }
            }
            ghost->sprite.move(x*ghost->speed, y*ghost->speed);
            ghost->x = ghost->x+(ghost->speed*x);
            ghost->y = ghost->y+(ghost->speed*y);

        }
            
}

void findKey(int id,Ghost* ghost,Key* key,Permit* permit,int& prev_direction)
{

    if (ghost->count==20000)
    {
        ghost->random=0;
        ghost->speed=0.00004;
        key->spawn=1;
        permit->spawn=1;
       // cout<<"DONE"<<endl;
    }
    ghost->count++;
    moverandom(ghost,prev_direction,id);
}

void mazemover(Ghost* ghost,int& prev_direction)
{
            float delta_x = 0, delta_y = 0;
            int direction;
            int x=0,y=0;
            float nx,ny;
            if (prev_direction==0){
                x=-1;
            }
            else if (prev_direction==1){
                x=1;
            }
            else if (prev_direction==2){
                y=-1;
            }
            else if (prev_direction==3){
                y=1;
            }
            //cout<<"P:"<<prev_direction<<endl;
            //cout<<"first:"<<ghost->x<<" "<<ghost->y<<endl;
            nx = ghost->x + x * ghost->sprite.getScale().x * CELL_SIZE;
            ny = ghost->y + y * ghost->sprite.getScale().y * CELL_SIZE;
            sf::FloatRect gBound = ghost->sprite.getGlobalBounds();
            gBound.left = nx;
            gBound.top = ny;
            bool collide=false;
            collide=checkwallghostcollision(gBound);
            //cout<<"C:"<<collide<<endl;
            //sf::sleep(sf::milliseconds(500));
            if (collide)
            {
                // Determine the valid directions based on the previous direction
                if (prev_direction == 2 || prev_direction == 3) 
                { // If previous direction was up or down
                    direction = rand() % 100; // Randomly select left or right
                    if (direction<50){
                        direction=0;
                    }
                    else{
                        direction=1;
                    }
                    //cout<<"hi"<<endl;
                
                } 
                else if (prev_direction == 0 || prev_direction == 1) 
                { // If previous direction was left or right
                direction = rand() % 100; // Randomly select up or down
                    if (direction<50)
                    {
                        direction=2;
                    }
                    else
                    {
                        direction=3;
                    }
                    //cout<<"hi there"<<endl;
                } 
                if (direction == 0)
                    delta_x = -1;
                else if (direction == 1)
                    delta_x = 1;
                else if (direction == 2)
                    delta_y = -1;
                else if (direction == 3)
                    delta_y = 1;

                // Calculate the new position
                float new_x = ghost->x + delta_x * ghost->sprite.getScale().x * CELL_SIZE;
                float new_y = ghost->y + delta_y * ghost->sprite.getScale().y * CELL_SIZE;

                // Check if the new position is within the bounds and not colliding with a wall
                if (new_x >= 0 && new_x < MAP_WIDTH * CELL_SIZE && new_y >= 0 && new_y < MAP_HEIGHT * CELL_SIZE) 
                {
                    sf::FloatRect ghostBounds = ghost->sprite.getGlobalBounds();
                    ghostBounds.left = new_x;
                    ghostBounds.top = new_y;
                    //cout<<"direction:"<<direction<<endl;
                    bool collision = false;
                    collision=checkwallghostcollision(ghostBounds);
                    //cout<<"------------------c2:"<<collision<<endl;
                    // If collision detected, find a valid direction randomly
                    if (collision) {
                        while (true) {
                            direction = rand() % 100; // Randomly select a direction
                            if (direction < 25 && ghost->x > 0) { // Move left
                                direction=0;
                                delta_x = -1;
                                delta_y = 0;
                            } else if (direction < 50 && ghost->x < (MAP_WIDTH - 1) * CELL_SIZE) { // Move right
                                direction=1;
                                delta_x = 1;
                                delta_y = 0;
                            } else if (direction < 75 && ghost->y > 0) { // Move up
                                direction=2;
                                delta_x = 0;
                                delta_y = -1;
                            } else if (direction < 100 && ghost->y < (MAP_HEIGHT - 1) * CELL_SIZE) { // Move down
                                direction=3;
                                delta_x = 0;
                                delta_y = 1;
                            }

                            // Calculate the new position
                            new_x = ghost->x + delta_x * ghost->sprite.getScale().x * CELL_SIZE;
                            new_y = ghost->y + delta_y * ghost->sprite.getScale().y * CELL_SIZE;

                            // Check if the new position is within the bounds and not colliding with a wall
                            sf::FloatRect tempGhostBounds = ghost->sprite.getGlobalBounds();
                            tempGhostBounds.left = new_x;
                            tempGhostBounds.top = new_y;

                            bool valid_move = true;
                            for (int i = 0; i < MAP_HEIGHT; ++i) {
                                for (int j = 0; j < MAP_WIDTH; ++j) {
                                    if (map_sketch[i][j] == '#') {
                                        sf::RectangleShape wall(sf::Vector2f(CELL_SIZE, CELL_SIZE));
                                        wall.setPosition(j * CELL_SIZE, i * CELL_SIZE);
                                        sf::FloatRect wallBounds = wall.getGlobalBounds();
                                        if (tempGhostBounds.intersects(wallBounds)) {
                                            valid_move = false;
                                            break;
                                        }
                                    }
                                }
                                if (!valid_move)
                                    break;
                            }

                            if (valid_move) {
                                break;
                            }
                            //cout<<new_x<<" "<<new_y<<endl;
                        }
                        
                    }
                    //cout<<new_x<<" "<<new_y<<endl;
                    // Move the ghost
                    // ghost->x = new_x;
                    // ghost->y = new_y;
                    // //cout<<"-------dir"<<direction<<endl;
                    // ghost->sprite.move(new_x*ghost->speed, new_y*ghost->speed);

                    //cout<<"D:"<<delta_x<<" "<<delta_y<<endl;
                    ghost->sprite.move(delta_x*ghost->speed, delta_y*ghost->speed);
                    ghost->x = ghost->x+(ghost->speed*delta_x);
                    ghost->y = ghost->y+(ghost->speed*delta_y);
                    //sf::sleep(sf::milliseconds(600));
                }

                // Update the previous direction
                    ghost->direction=direction;
                    prev_direction = direction;
            }
            else{
                //  delta_x = x * ghost->speed;
                // delta_y = y * ghost->speed;
                // // Update ghost position using move function
                // ghost->sprite.move(delta_x, delta_y);
                // ghost->x += delta_x;
                // ghost->y += delta_y;
                //cout<<"D2:"<<x<<" "<<y<<endl;
                //cout<<nx<<" "<<ny<<endl;
                //cout<<ghost->x<<" "<<ghost->y<<endl;
                ghost->sprite.move(x*ghost->speed, y*ghost->speed);
                ghost->x = ghost->x+(ghost->speed*x);
                ghost->y = ghost->y+(ghost->speed*y);
                //sf::sleep(sf::milliseconds(600));

            }

}

//collision between pacman and ghost 
bool pacman_ghost_collision(sf::FloatRect ghostBounds, FloatRect Pacmanbounds){
    bool collision=false;
    
    if (ghostBounds.intersects(Pacmanbounds) ) 
    {

        return true;
    }
                            
    return collision;
}


void* ghost1Thread(void* arg) 
{
    RenderData* args = static_cast<RenderData*>(arg);
    Ghost* ghost = args->ghost;
    Ghost* g4=args->ghost4;
    Ghost* g2=args->ghost2;
    Ghost* g3=args->ghost3;
    Pacman* pac=args->pacman;
    
    Key* key=args->k1;
    Permit* permit=args->p1;
    const char(*map)[MAP_WIDTH + 1] = map_sketch;
    int prev_direction = 3; // Initialize previous direction
    ghost->direction=prev_direction;
    //Clock clock;
    ghost->clock.restart();

    while (args->window->isOpen()) {
        if (pac->powercheck && ghost->set==0 )
        {
            ghost->changeimage("Resources/blueghost.png");
            ghost->set=1;
            
        }
        else if (pac->powercheck==0 && ghost->set==1)
        {
            ghost->changeimage("Resources/ghost1.png");
            ghost->set=0;
        }

        if (ghost->house==1)
        {
            sem_wait(&semaphore);
            if (ghost->random==1)
            findKey(0,ghost,key,permit,prev_direction);
            sem_post(&semaphore);
            sem_wait(&semaphore);
            if (ghost->random==0)
            {
                if (ghost->yPos > ghost->y)
                {
                    //ghost->speed=0.001;
                    move(ghost,"d");
                }
                else if (ghost->yPos < ghost->y)
                {
                    //ghost->speed=0.001;
                    move(ghost,"u");
                }
                
                sf::Time elapsed = ghost->clock.getElapsedTime();

                // Convert elapsed time to seconds
                float seconds = elapsed.asSeconds();
                //cout<<seconds<<endl;
                if (seconds>10 && ::key>0 && ::permit>0)
                {
                        philosopher(0,&ghost,&ghost,&g2,&g3,&g4);
                        //cout<<"-----------------------------1"<<endl;
                }
                   
            }
            sem_post(&semaphore);
        }
        else
        {
        if (ghost->moveout) 
        {
            if (!ghost->pickup)
            {
                float tempx=ghost->x;
                float tempy=ghost->y;
                ghost->sprite.setPosition(key->x,key->y);
                sleep(milliseconds(500));
                ghost->sprite.setPosition(tempx,tempy);
                sleep(milliseconds(500));
                ghost->sprite.setPosition(permit->x,permit->y);
                sleep(milliseconds(500));
                ghost->sprite.setPosition(tempx,tempy);
                ghost->pickup=1;
                g2->pickup=1;
                g3->pickup=1;
                g4->pickup=1;
            }

             float dy=6*CELL_SIZE;
             if (ghost->y>dy)
             {
                ghost->speed=0.0001;
                move(ghost,"u");
             }
             else{
                ghost->moveout=0;
                //sleep(1);
             }

        }
        else
        {
            ghost->speed=0.01;
            if (ghost->eaten){
                ghost->speed=0.09;
            }
            sf::FloatRect tempGhostBounds = ghost->sprite.getGlobalBounds();
            sf::FloatRect pacmanbounds=pac->sprite.getGlobalBounds();
            if (pacman_ghost_collision(tempGhostBounds,pacmanbounds) )
            {
                //cout<<"collison"<<endl;
                if (pac->powercheck)
                {
                    ghost->x=10*CELL_SIZE;
                    ghost->y=9*CELL_SIZE;
                    ghost->sprite.setPosition(ghost->x,ghost->y);
                    ghost->moveout=0;
                    ::key++;
                    ::permit++;
                     for (int i=0;i<N;i++)
                        state[i]=2;
                    //ate[0]=false;
                    if (::key ==1 && ::permit==1)
                    {
                         ghost->house=1;
                         ghost->escaped=false;
                         ghost->random=0;
                        ghost->resetvariables();

                         //ghost->resetvariables();
                         //ghost->clock.restart();

                         if (!g2->escaped && !g3->escaped)
                        {
                            if (ate[1]==true && ate[2]==true )
                            {
                                ate[0]=false;
                                ate[1]=false;
                                ate[2]=false;
                            }
                        }
                        else if (!g2->escaped && !g4->escaped)
                        {
                            if (ate[1]==true && ate[3]==true )
                            {
                                ate[0]=false;
                                ate[1]=false;
                                ate[3]=false;
                            }
                        }
                        else if (!g3->escaped && !g4->escaped)
                        {
                            if (ate[2]==true && ate[3]==true )
                            {
                                ate[0]=false;
                                ate[2]=false;
                                ate[3]=false;
                            }
                        }

                        if (!g2->escaped)
                        {
                            g2->random=0;
                            //g2->clock.restart();
                        }
                        if (!g3->escaped)
                        {
                            g3->random=0;
                            //g3->clock.restart();
                        }
                        if (!g4->escaped)
                        {
                            g4->random=0;
                            //g4->clock.restart();
                        }
                        // // ghost->random=1;
                        // // ghost->count=0;
                        // ghost->clock.restart();

                        // // g2->house=1;
                        // // g2->random=1;
                        // // g2->count=0;
                        // g2->clock.restart();

                        // // g3->house=1;
                        // // g3->random=1;
                        // // g3->count=0;
                        // g3->clock.restart();

                        // // g4->house=1;
                        // // g4->random=1;
                        // // g4->count=0;
                        // g4->clock.restart();

                        //setinitialPosition(ghost,g2,g3,g4);


                    }
                }
                else
                {
                    pac->x = 3*CELL_SIZE, pac->y = 5*CELL_SIZE;
                    pac->sprite.setPosition(pac->x, pac->y);
                    pac->lives--;
                }
                
            }
            
            
            else
            {
                sem_wait(&semaphore);
                mazemover(ghost,prev_direction);
                sem_post(&semaphore);
            }
        }
       }

        // Sleep for some time before the next move
        //sf::sleep(sf::milliseconds(500)); // Adjust this value to change the speed of the ghost
    }

    return nullptr;
}


//ghost 2 thread
void* ghost2Thread(void* arg) {
    RenderData* args = static_cast<RenderData*>(arg);
    Ghost* ghost = args->ghost2;
    Ghost* g1=args->ghost;
    Ghost* g4=args->ghost4;
    Ghost* g3=args->ghost3;
    Pacman* pac=args->pacman;
    
    Key* key=args->k1;
    Permit* permit=args->p2;
    const char(*map)[MAP_WIDTH + 1] = map_sketch;
    int prev_direction = 0; // Initialize previous direction
    ghost->direction=prev_direction;
    //Clock clock;
    ghost->clock.restart();
    

    while (args->window->isOpen()) {
        if (pac->powercheck && ghost->set==0 )
        {
            ghost->changeimage("Resources/blueghost.png");
            ghost->set=1;
            
        }
        else if (pac->powercheck==0 && ghost->set==1)
        {
            ghost->changeimage("Resources/ghost2.png");
            ghost->set=0;
        }
        if (ghost->house==1)
        {
            sem_wait(&semaphore2);
            if (ghost->random==1)
            {
                findKey(1,ghost,key,permit,prev_direction);
            }
            sem_post(&semaphore2);
            sem_wait(&semaphore2);
            if (ghost->random==0)
            {
                if (ghost->xPos > ghost->x)
                {
                    //ghost->speed=0.001;
                    move(ghost,"r");
                }
                else if (ghost->xPos < ghost->x)
                {
                    //ghost->speed=0.001;
                    move(ghost,"l");
                }
                else{
                    ghost->speed=0;
                    
                }
                
                sf::Time elapsed = ghost->clock.getElapsedTime();

                // Convert elapsed time to seconds
                float seconds = elapsed.asSeconds();
                if (seconds>10 && ::key>0 && ::permit>0)
                {
                        philosopher(1,&ghost,&g1,&ghost,&g3,&g4);
                        //cout<<"-----------------------------2"<<endl;
                }

                   
            }
            sem_post(&semaphore2);
            
        }
        else
        {
        if (ghost->moveout)
        {
            if (!ghost->pickup)
            {
                float tempx=ghost->x;
                float tempy=ghost->y;
                ghost->sprite.setPosition(key->x,key->y);
                sleep(milliseconds(500));
                ghost->sprite.setPosition(tempx,tempy);
                sleep(milliseconds(500));
                ghost->sprite.setPosition(permit->x,permit->y);
                sleep(milliseconds(500));
                ghost->sprite.setPosition(tempx,tempy);
                ghost->pickup=1;
                g1->pickup=1;
                g3->pickup=1;
                g4->pickup=1;
            }
             float dy=6*CELL_SIZE;
             if (ghost->y>dy)
             {
                ghost->speed=0.0001;
                move(ghost,"u");
             }
             else
             {
                ghost->moveout=0;
             }

        }
        else
        {
            ghost->speed=0.01;
            if (ghost->eaten){
                ghost->speed=0.09;
            }
            sf::FloatRect tempGhostBounds = ghost->sprite.getGlobalBounds();
            sf::FloatRect pacmanbounds=pac->sprite.getGlobalBounds();
            if (pacman_ghost_collision(tempGhostBounds,pacmanbounds))
            {
                if (pac->powercheck)
                {
                    ghost->x=9*CELL_SIZE;
                    ghost->y=10*CELL_SIZE;
                    ghost->sprite.setPosition(ghost->x,ghost->y);
                    ghost->moveout=0;
                    //setinitialPosition(g1,ghost,g3,g4);

                    ::key++;
                    ::permit++;
                    //ate[1]=false;
                    for (int i=0;i<N;i++)
                        state[i]=2;
                    //ate[1]=false;
                    if (::key ==1 && ::permit==1)
                    {
                        ghost->house=1;
                         ghost->escaped=false;
                         ghost->random=0;
                         ghost->resetvariables();
                         //ghost->clock.restart();

                        if (!g1->escaped && !g3->escaped)
                        {
                            if (ate[0]==true && ate[2]==true )
                            {
                                ate[0]=false;
                                ate[1]=false;
                                ate[2]=false;
                            }
                        }
                        else if (!g4->escaped && !g1->escaped)
                        {
                            if (ate[3]==true && ate[0]==true )
                            {
                                ate[0]=false;
                                ate[1]=false;
                                ate[3]=false;
                            }
                        }
                        else if (!g3->escaped && !g4->escaped)
                        {
                            if (ate[2]==true && ate[3]==true )
                            {
                                ate[1]=false;
                                ate[2]=false;
                                ate[3]=false;
                            }
                        }

                        if (!g4->escaped)
                        {
                            g4->random=0;
                            //g4->clock.restart();
                        }
                        if (!g3->escaped)
                        {
                            g3->random=0;
                            //g3->clock.restart();
                        }
                        if (!g1->escaped)
                        {
                            g1->random=0;
                            //g1->clock.restart();
                        }
                        // ghost->random=1;
                        // ghost->count=0;
                        // ghost->clock.restart();

                        // // g1->house=1;
                        // // g1->random=1;
                        // // g1->count=0;
                        // g1->clock.restart();

                        // // g3->house=1;
                        // // g3->random=1;
                        // // g3->count=0;
                        // g3->clock.restart();

                        // // g4->house=1;
                        // // g4->random=1;
                        // // g4->count=0;
                        // g4->clock.restart();
                        //setinitialPosition(g1,ghost,g3,g4);



                    }
                }
                else
                {
                    pac->x = 3*CELL_SIZE, pac->y = 5*CELL_SIZE;
                    pac->sprite.setPosition(pac->x, pac->y);
                    pac->lives--;

                }
            }
            else 
            {
                sem_wait(&semaphore2);
                mazemover(ghost,prev_direction);
                sem_post(&semaphore2);
            }
        }
        }

        // Sleep for some time before the next move
        //sf::sleep(sf::milliseconds(500)); // Adjust this value to change the speed of the ghost
    }

    return nullptr;
}
//ghost 3 thread
void* ghost3Thread(void* arg) {
    RenderData* args = static_cast<RenderData*>(arg);
    Ghost* ghost = args->ghost3;
    Ghost* g1=args->ghost;
    Ghost* g2=args->ghost2;
    Ghost* g4=args->ghost4;
    Pacman* pac=args->pacman;
    
    const char(*map)[MAP_WIDTH + 1] = map_sketch;
    int prev_direction = 3; // Initialize previous direction
    ghost->direction=prev_direction;
    Key* key=args->k2;
    Permit* permit=args->p2;
    //Clock clock;
    ghost->clock.restart();
    while (args->window->isOpen()) {
        if (pac->powercheck && ghost->set==0 )
        {
            ghost->changeimage("Resources/blueghost.png");
            ghost->set=1;
            
        }
        else if (pac->powercheck==0 && ghost->set==1)
        {
            ghost->changeimage("Resources/ghost3.png");
            ghost->set=0;
        }
        if (ghost->house==1)
        {
            sem_wait(&semaphore3);
            if (ghost->random==1)
            {
                findKey(2,ghost,key,permit,prev_direction);
            }
            sem_post(&semaphore3);
            sem_wait(&semaphore3);
           if (ghost->random==0)
            {
                if (ghost->yPos > ghost->y)
                {
                    //ghost->speed=0.001;
                    move(ghost,"d");
                }
                else if (ghost->yPos < ghost->y)
                {
                    //ghost->speed=0.001;
                    move(ghost,"u");
                }
                else{
                    ghost->speed=0;
                    
                }
                
                sf::Time elapsed = ghost->clock.getElapsedTime();

                // Convert elapsed time to seconds
                float seconds = elapsed.asSeconds();
                if (seconds>10 && ::key>0 && ::permit>0)
                {
                        philosopher(2,&ghost,&g1,&g2,&ghost,&g4);
                        //cout<<"-----------------------------3"<<endl;
                }

                
                   
            }
            sem_post(&semaphore3);
            
        }
        else
        {
        if (ghost->moveout)
        {
            if (!ghost->pickup)
            {
                float tempx=ghost->x;
                float tempy=ghost->y;
                ghost->sprite.setPosition(key->x,key->y);
                sleep(milliseconds(500));
                ghost->sprite.setPosition(tempx,tempy);
                sleep(milliseconds(500));
                ghost->sprite.setPosition(permit->x,permit->y);
                sleep(milliseconds(500));
                ghost->sprite.setPosition(tempx,tempy);
                ghost->pickup=1;
                ghost->pickup=1;
                g2->pickup=1;
                g1->pickup=1;
                g4->pickup=1;
            }
             float dy=6*CELL_SIZE;
             if (ghost->y>dy)
             {
                ghost->speed=0.0001;
                move(ghost,"u");
             }
             else{
                ghost->moveout=0;
             }

        }
        else
        {
            ghost->speed=0.01;
            if (ghost->eaten){
                ghost->speed=0.09;
            }
            sf::FloatRect tempGhostBounds = ghost->sprite.getGlobalBounds();
            sf::FloatRect pacmanbounds=pac->sprite.getGlobalBounds();
            if (pacman_ghost_collision(tempGhostBounds,pacmanbounds))
            {
                if (pac->powercheck)
                {
                    ghost->x=11*CELL_SIZE;
                    ghost->y=10*CELL_SIZE;
                    ghost->sprite.setPosition(ghost->x,ghost->y);
                    ghost->moveout=0;

                    //setinitialPosition(g1,g2,ghost,g4);

                    ::key++;
                    ::permit++;
                    //ate[2]=false;
                     for (int i=0;i<N;i++)
                        state[i]=2;
                    //ate[2]=false;
                    if (::key ==1 && ::permit==1)
                    {
                         ghost->house=1;
                         ghost->escaped=false;
                         ghost->random=0;
                        ghost->resetvariables();

                         //ghost->clock.restart();

                         if (!g2->escaped && !g1->escaped)
                        {
                            if (ate[1]==true && ate[0]==true )
                            {
                                ate[2]=false;
                                ate[1]=false;
                                ate[0]=false;
                            }
                        }
                        else if (!g2->escaped && !g4->escaped)
                        {
                            if (ate[1]==true && ate[3]==true )
                            {
                                ate[2]=false;
                                ate[1]=false;
                                ate[3]=false;
                            }
                        }
                        else if (!g4->escaped && !g1->escaped)
                        {
                            if (ate[3]==true && ate[0]==true )
                            {
                                ate[0]=false;
                                ate[2]=false;
                                ate[3]=false;
                            }
                        }


                        if (!g2->escaped)
                        {
                            g2->random=0;
                            //g2->clock.restart();
                        }
                        if (!g4->escaped)
                        {
                            g4->random=0;
                            //g4->clock.restart();
                        }
                        if (!g1->escaped)
                        {
                            g1->random=0;
                            //g1->clock.restart();
                        }
                        // // ghost->random=1;
                        // // ghost->count=0;
                        // ghost->clock.restart();

                        // // g2->house=1;
                        // // g2->random=1;
                        // // g2->count=0;
                        // g2->clock.restart();

                        // // g1->house=1;
                        // // g1->random=1;
                        // // g1->count=0;
                        // g1->clock.restart();

                        // // g4->house=1;
                        // // g4->random=1;
                        // // g4->count=0;
                        // g4->clock.restart();
                        //setinitialPosition(g1,g2,ghost,g4);



                    }
                }
                else
                {
                    pac->x = 3*CELL_SIZE, pac->y = 5*CELL_SIZE;
                    pac->sprite.setPosition(pac->x, pac->y);
                    pac->lives--;

                }
            }
            else 
            {
                sem_wait(&semaphore3);
                mazemover(ghost,prev_direction);
                sem_post(&semaphore3);
            }
        }
        }

        // Sleep for some time before the next move
        //sf::sleep(sf::milliseconds(500)); // Adjust this value to change the speed of the ghost
    }

    return nullptr;
}
//ghost 4 thread
void* ghost4Thread(void* arg) 
{
    RenderData* args = static_cast<RenderData*>(arg);
    Ghost* ghost = args->ghost4;
    Ghost* g1=args->ghost;
    Ghost* g2=args->ghost2;
    Ghost* g3=args->ghost3;
    Pacman* pac=args->pacman;
    
    const char(*map)[MAP_WIDTH + 1] = map_sketch;
    int prev_direction = 1; // Initialize previous direction
    ghost->direction=prev_direction;
    Key* key=args->k2;
    Permit* permit=args->p1;
    //Clock clock;
    bool check=false;
    ghost->clock.restart();
    while (args->window->isOpen()) {
        if (pac->powercheck && ghost->set==0)
        {
            ghost->changeimage("Resources/blueghost.png");
            ghost->set=1;
            
        }
        else if (pac->powercheck==0 && ghost->set==1)
        {
            ghost->changeimage("Resources/ghost4.png");
            ghost->set=0;
        }
        if (ghost->house==1)
        {
            sem_wait(&semaphore4);
            if (ghost->random==1)
            {
                findKey(3,ghost,key,permit,prev_direction);
            }
            sem_post(&semaphore4);
            sem_wait(&semaphore4);
             if (ghost->random==0)
            {
                if (ghost->xPos > ghost->x)
                {
                    //ghost->speed=0.001;
                    move(ghost,"r");
                }
                else if (ghost->xPos < ghost->x)
                {
                    //ghost->speed=0.001;
                    move(ghost,"l");
                }
                else{

                    ghost->speed=0;
                    
                }
                
                sf::Time elapsed = ghost->clock.getElapsedTime();

                // Convert elapsed time to seconds
                float seconds = elapsed.asSeconds();
                if (seconds>10 && ::key>0 && ::permit>0)
                {
                        philosopher(3,&ghost,&g1,&g2,&g3,&ghost);
                        //cout<<"-----------------------------4"<<endl;
                }
                   
            }
            sem_post(&semaphore4);

            
        }
        else
        {
        if (ghost->moveout)
        {
             if (!ghost->pickup)
            {
                float tempx=ghost->x;
                float tempy=ghost->y;
                ghost->sprite.setPosition(key->x,key->y);
                sleep(milliseconds(500));
                ghost->sprite.setPosition(tempx,tempy);
                sleep(milliseconds(500));
                ghost->sprite.setPosition(permit->x,permit->y);
                sleep(milliseconds(500));
                ghost->sprite.setPosition(tempx,tempy);
                ghost->pickup=1;
                ghost->pickup=1;
                g2->pickup=1;
                g3->pickup=1;
                g1->pickup=1;
            }
             float dy=6*CELL_SIZE;
             if (ghost->y>dy)
             {
                ghost->speed=0.0001;
                move(ghost,"u");
             }
             else
             {
                ghost->moveout=0;
             }

        }
        else
        {
            ghost->speed=0.01;
            if (ghost->eaten){
                ghost->speed=0.09;
            }
            sf::FloatRect tempGhostBounds = ghost->sprite.getGlobalBounds();
            sf::FloatRect pacmanbounds=pac->sprite.getGlobalBounds();
            if (pacman_ghost_collision(tempGhostBounds,pacmanbounds))
            {
                if (pac->powercheck)
                {
                    ghost->x=10*CELL_SIZE;
                    ghost->y=11*CELL_SIZE;
                    ghost->sprite.setPosition(ghost->x,ghost->y);
                    ghost->moveout=0;

                    //setinitialPosition(g1,g2,g3,ghost);
                    ::key++;
                    ::permit++;
                    //ate[3]=false;
                    //ate[3]=false;
                    //  if (ate[0]==true && ate[1]==true && ate[2]==true && ate[3]==true)
                    //  {

                    //  }

                    for (int i=0;i<N;i++)
                        state[i]=2;
                    if (::key ==1 && ::permit==1)
                    {
                        ghost->house=1;
                         ghost->escaped=false;
                         ghost->random=0;
                        ghost->resetvariables();

                        //ghost->resetvariables();

                         //ghost->clock.restart();
                        if (!g2->escaped && !g3->escaped)
                        {
                            if (ate[1]==true && ate[2]==true )
                            {
                                ate[3]=false;
                                ate[1]=false;
                                ate[2]=false;
                            }
                        }
                        else if (!g2->escaped && !g1->escaped)
                        {
                            if (ate[1]==true && ate[0]==true )
                            {
                                ate[0]=false;
                                ate[1]=false;
                                ate[3]=false;
                            }
                        }
                        else if (!g3->escaped && !g1->escaped)
                        {
                            if (ate[2]==true && ate[0]==true )
                            {
                                ate[0]=false;
                                ate[2]=false;
                                ate[3]=false;
                            }
                        }
                        

                        if (!g2->escaped)
                        {
                            g2->random=0;
                            //g2->clock.restart();
                        }
                        if (!g3->escaped)
                        {
                            g3->random=0;
                            //g3->clock.restart();
                        }
                        if (!g1->escaped)
                        {
                            g1->random=0;
                            //g1->clock.restart();
                        }
                        // // ghost->random=1;
                        // // ghost->count=0;
                        // ghost->clock.restart();

                        // // g2->house=1;
                        // // g2->random=1;
                        // // g2->count=0;
                        // g2->clock.restart();

                        // // g3->house=1;
                        // // g3->random=1;
                        // // g3->count=0;
                        // g3->clock.restart();

                        // // g1->house=1;
                        // // g1->random=1;
                        // // g1->count=0;
                        // g1->clock.restart();



                    }
                }
                else
                {
                    pac->x = 3*CELL_SIZE, pac->y = 5*CELL_SIZE;
                    pac->sprite.setPosition(pac->x, pac->y);
                    pac->lives--;

                }
            }
            else 
            {
                sem_wait(&semaphore4);
                mazemover(ghost,prev_direction);
                sem_post(&semaphore4);
            }
        }
        }

        // Sleep for some time before the next move
        //sf::sleep(sf::milliseconds(500)); // Adjust this value to change the speed of the ghost
    }

    return nullptr;
}



void* renderThread(void* arg)
{
    //pthread_mutex_lock(&mutex);
    RenderData* args= static_cast<RenderData*>(arg);
    RenderWindow *window = args->window;
    Pacman* pacman=args->pacman;
    FastPellet* fp1=args->fp1;
    bool collision_left=false;
    bool collision_right=false;
    bool collision_up=false;
    bool collision_down=false;
    bool clockcheck=false;
    Clock clock;
    //sf::Event event;
    ////cout<<*(renderData->isWindowOpen)<<endl;
    while (args->window->isOpen())
    {
        pacman->pmove=pacman->movement;
        checkcoincollision(pacman);
        if (!pacman->powercheck)
            checkpowerpelletcollision(pacman,*fp1);
        if (pacman->powercheck)
        {
            if (!clockcheck)
            {
                clock.restart();
                clockcheck=true;
            }
            sf::Time elapsed = clock.getElapsedTime();

                // Convert elapsed time to seconds
            float seconds = elapsed.asSeconds();
            if (seconds>10)
            {
                pacman->powercheck=false;
                clockcheck=false;
               // cout<<"Power deactivated "<<endl;
            }
            
        }


        if (sf::Keyboard::isKeyPressed(Keyboard::Left))
        {
            pacman->movement='l';
            pthread_mutex_lock(&mutex);
            if (!pacman->checkplayercollision("l"))
                pacman->move("l");
            pthread_mutex_unlock(&mutex);

        }
        else if (Keyboard::isKeyPressed(Keyboard::Right))
        {
            pacman->movement='r';
            pthread_mutex_lock(&mutex);
            if (!pacman->checkplayercollision("r"))
                pacman->move("r");
            pthread_mutex_unlock(&mutex);
        }
        else if (Keyboard::isKeyPressed(Keyboard::Up))
        {
            pacman->movement='u';
            pthread_mutex_lock(&mutex);
            if (!pacman->checkplayercollision("u"))
                pacman->move("u");
            pthread_mutex_unlock(&mutex);
        }
        else if (Keyboard::isKeyPressed(Keyboard::Down) )
        {
            pacman->movement='d';
            pthread_mutex_lock(&mutex);
            if (!pacman->checkplayercollision("d"))
                pacman->move("d");
            pthread_mutex_unlock(&mutex);
        }
        
        
    }
    
    //pthread_mutex_unlock(&mutex);
    return nullptr;
}

bool checkpelletcollision(sf::FloatRect ghostBounds){
    bool collision=false;
    for (int i = 0; i < MAP_HEIGHT; ++i) 
    {
                for (int j = 0; j < MAP_WIDTH; ++j) {
                    if (map_sketch[i][j] == '#') {
                        sf::RectangleShape wall(sf::Vector2f(CELL_SIZE, CELL_SIZE));
                        wall.setPosition(j * CELL_SIZE, i * CELL_SIZE);
                        sf::FloatRect wallBounds = wall.getGlobalBounds();
                        if (ghostBounds.intersects(wallBounds)) {
                            collision = true;
                            ////cout<<wallBounds.left<<" "<<wallBounds.top<<endl;
                            break;
                        }
                    }
                }
                if (collision)
                    break;
                //sem_post(&sem2);
        }
        return collision;

}


// bool checkfastpelletcollision(Ghost& ghost)
// {
//         float nx,ny;
//         nx = ghost.x + (ghost.sprite.getScale().x-0.17) * CELL_SIZE;
//         ny = ghost.y + (ghost.sprite.getScale().y-0.17) * CELL_SIZE;
//         sf::FloatRect gBound = ghost.sprite.getGlobalBounds();
//         gBound.left = nx;
//         gBound.top = ny;
//         ////cout<<pacmanBounds<<endl;
//         sf::CircleShape pellet(CELL_SIZE/4.5);
//         bool collision=false;
//         for (int i = 0; i < MAP_HEIGHT; ++i) 
//         {
//                 for (int j = 0; j < MAP_WIDTH; ++j) {
//                     if (map_sketch[j][i] == 'F') {
//                         pellet.setPosition(static_cast<float>(CELL_SIZE * i)+3.5, static_cast<float>(CELL_SIZE * j)+3.5);
//                         sf::FloatRect fpelletbounds = pellet.getGlobalBounds();
//                         if (gBound.intersects(fpelletbounds)) 
//                         {
//                             cout<<"collision"<<endl;
//                             collision = true;
//                             break;
//                         }
//                     }
//                 }
//                 if (collision)
//                     break;
//         }
//         return collision;

// }

void checkghostspeed(Ghost& ghost){
    if (ghost.eaten)
    {
        if (ghost.checktime())
        {
            //cout<<"come on"<<endl;
            ghost.eaten=0;
            ghost.speed=0.01;
        }
    }
}

void checkplayerscore(string name,int score){
    string str[50];
    int scr[50];
    string s2;
    fstream file;
    file.open("leaderboard", ios::out | ios::app);
    file << name << "\t" << score << endl;
    file.close();

    // Read data from file and write to temp file with newline characters
    fstream infile;
    infile.open("leaderboard", ios::in);
    fstream outfile;
    outfile.open("temp", ios::out | ios::app);
    getline(infile, s2,'\n');
    while (!infile.eof()) {
        outfile << s2 << endl;
        getline(infile, s2,'\n');
    }
    infile.close();
    outfile.close();
    // Replace original file with temp file
    remove("leaderboard");
    rename("temp", "leaderboard");
    fstream readfile;
    readfile.open("leaderboard", ios::in);
    int i=0;
    int size=0;
    string s1;
    string s3;
      while (!readfile.eof()) {
        getline(readfile,s1,'\n');
        str[i]=s1;
        i++;
        size++;
    }
    size--;
    readfile.close();
    // for (int i=0;i<size;i++){
    //     cout<<str[i]<<endl;
    // }
    int j=0;
     readfile.open("leaderboard", ios::in);
         while (!readfile.eof()) {
         getline(readfile,s1,'\t');
         getline(readfile,s3,'\n');
         scr[j]=stoi(s3);
         j++;
     }
//   for (int i=0;i<size;i++){
//          cout<<scr[i]<<endl;
//      }
 for (int i = 0; i < size; i++) {
    for (int j = 0; j < size - i - 1; j++) {
      if (scr[j] < scr[j + 1]) {
        // Swap the elements
        int temp = scr[j];
        scr[j] = scr[j + 1];
        scr[j + 1] = temp;
        // Swap the names
        string temp_name = str[j];
        str[j] = str[j + 1];
        str[j + 1] = temp_name;
      }
    }
  }
//   cout<<"after sort : "<<endl;
//    for (int i=0;i<size;i++){
//          cout<<str[i]<<endl;
//      }
 
       fstream ofile;
     ofile.open("temp", ios::out | ios::app);
     int k=0;
      while (k<size) {
         ofile <<str[k]<<endl;
          k++;
      }
     remove("leaderboard");
     rename("temp", "leaderboard");  
}

int main()
{
    XInitThreads();
    

    char map[MAP_HEIGHT][MAP_WIDTH];
    for (int i = 0; i < MAP_HEIGHT; ++i) {
        for (int j = 0; j < MAP_WIDTH; ++j) {
            map[i][j] = map_sketch[i][j];
        }
    }


    //taking user input 
    sf::RenderWindow window3(sf::VideoMode(800, 600), "Username Input");
    sf::Font font1;
    if (!font1.loadFromFile("Resources/Lot.otf")) { // Load a font
        std::cerr << "Failed to load font." << std::endl;
        return 1;
    }
    sf::Font font10;
     if (!font10.loadFromFile("Resources/score.ttf")) {
        std::cerr << "Failed to load font!" << std::endl;
        return -1;
    }
    sf::Text usernameText;
    usernameText.setFont(font10);
    usernameText.setCharacterSize(24);
    usernameText.setFillColor(sf::Color::Black);
    usernameText.setPosition(10, 10);
    usernameText.setString("Enter your username:");

    sf::RectangleShape inputBox(sf::Vector2f(300, 40));
    inputBox.setPosition(10, 50);
    inputBox.setFillColor(sf::Color::White);
    inputBox.setOutlineThickness(2);
    inputBox.setOutlineColor(sf::Color::Black);

    sf::Text userInput;
    userInput.setFont(font10);
    userInput.setCharacterSize(24);
    userInput.setFillColor(sf::Color::Black);
    userInput.setPosition(15, 55);

    std::string username;

    while (window3.isOpen()) {
        sf::Event event;
        while (window3.pollEvent(event)) {
            if (event.type == sf::Event::Closed) {
                window3.close();
            }
            else if (event.type == sf::Event::KeyPressed && event.key.code == sf::Keyboard::Return)
                    window3.close();
            else if (event.type == sf::Event::TextEntered) {
                if (event.text.unicode < 128) { // Check if the entered character is ASCII
                    if (event.text.unicode == '\b' && !username.empty()) { // Backspace
                        username.pop_back();
                    } else if (event.text.unicode != '\b' && username.size() < 20) { // Limiting username to 20 characters
                        username += static_cast<char>(event.text.unicode);
                    }
                    userInput.setString(username);
                }
            }
        }

        window3.clear(sf::Color::White);
        window3.draw(usernameText);
        window3.draw(inputBox);
        window3.draw(userInput);
        window3.display();
    }

    std::cout << "Username entered: " << username << std::endl;









    sf::RenderWindow window2(sf::VideoMode(800, 600), "MENU");
    sf::Texture texture;
    if (!texture.loadFromFile("Resources/men4.png")) {
        // Error handling if image loading fails
        return EXIT_FAILURE;
    }
     sf::Font font;
    if (!font.loadFromFile("Resources/Lot.otf")) {
        // Error handling if font loading fails
        return EXIT_FAILURE;
    }

    // Create a text object
    sf::Text text;
    Text text2;
    Text text3;
    Text text4;


    text.setFont(font);
    text.setString(" (1) PLAY GAME");
    text.setCharacterSize(31);
    text.setFillColor(sf::Color::White);
    text.setPosition(428, 200);

    text2.setFont(font);
    text2.setString(" (2) INSTRUCTIONS");
    text2.setCharacterSize(31);
    text2.setFillColor(sf::Color::White);
    text2.setPosition(428, 260);



    text3.setFont(font);
    text3.setString(" (3) LEADERBOARDS");
    text3.setCharacterSize(31);
    text3.setFillColor(sf::Color::White);
    text3.setPosition(428, 320);


    text4.setFont(font);
    text4.setString(" (4) QUIT");
    text4.setCharacterSize(31);
    text4.setFillColor(sf::Color::White);
    text4.setPosition(428, 380);


    bool showInstructions = false;
    bool showleader=false;

    sf::Texture instructionsTexture;
    if (!instructionsTexture.loadFromFile("Resources/instructions.png")) {
        std::cerr << "Error loading instructions image!" << std::endl;
        return 1;
    }

    sf::Sprite instructionsSprite;
    instructionsSprite.setTexture(instructionsTexture);
    bool game=0;
    sf::Sprite sprite(texture);
    //sprite.setScale(0.5,0.5);

    // Main loop
    while (window2.isOpen()) {
        // Process events
        sf::Event event;
        while (window2.pollEvent(event)) 
        {
            if (event.type == sf::Event::Closed)
                window2.close();
            if (event.type == sf::Event::KeyPressed)
            {
                if (event.key.code == sf::Keyboard::Escape){
                    if (showInstructions || showleader){
                        showInstructions = false;
                        showleader=false;
                    }
                }
                else if (event.key.code == sf::Keyboard::Num4)
                {
                window2.close();
                }
                else if (event.key.code == sf::Keyboard::Num2)
                    showInstructions = true;
                else if (event.key.code == sf::Keyboard::Num1)
                {
                    game=true;
                    //window2.setVisible(false);
                    window2.close();
                }
                else if (event.key.code == sf::Keyboard::Num3)
                {
                    showleader=true;
                }
            }
        }

        // Clear the window with a background color (here, white)

        // Draw the sprite
        if (showInstructions){
            window2.clear(sf::Color::Black);
            window2.draw(instructionsSprite);
        }
        else if (showleader)
        {
            window2.clear(sf::Color::Black);
            //cout<<"reached"<<endl;
            fstream file;
            file.open("leaderboard", ios::in);
            //std::ifstream file("/home/abd/Documents/project_1/leaderboard.txt");
            if (!file.is_open()) {
                cout<<"file errror"<<endl;
                return -1; // handle error
            }

            std::stringstream buffer;
            buffer << file.rdbuf();
            std::string fileContents = buffer.str();

            // Create a text object
            sf::Text text;
            text.setFont(font10);
            text.setString(fileContents);
            text.setCharacterSize(31);
            text.setFillColor(sf::Color::White);
            window2.draw(text);
        }
        else{
            window2.clear(sf::Color::Black);
            window2.draw(instructionsSprite);
            window2.draw(sprite);
            window2.draw(text);
            window2.draw(text2);
            window2.draw(text3);
            window2.draw(text4);
        }

        // Display the window
        window2.display(); 
    }

    if (game)
    {
        //window2.close();
     sf::RenderWindow window(sf::VideoMode((CELL_SIZE * MAP_WIDTH * SCREEN_RESIZE), (FONT_HEIGHT + CELL_SIZE * MAP_HEIGHT) * SCREEN_RESIZE), "Pac-Man", sf::Style::Close);

    window.setView(sf::View(sf::FloatRect(0, 0, CELL_SIZE * MAP_WIDTH, FONT_HEIGHT + CELL_SIZE * MAP_HEIGHT)));
    
    //bool isWindowOpen = true;
    Pacman pacman("Resources/pacman.png");
    Ghost g1("Resources/ghost1.png");
    Ghost g2("Resources/ghost2.png");
    Ghost g3("Resources/ghost3.png");
    Ghost g4("Resources/ghost4.png");
    Permit p1("Resources/permit.png");
    Permit p2("Resources/permit.png");
    Key k1("Resources/key.png");
    Key k2("Resources/key.png");
    FastPellet fp1;

    k2.x=11*CELL_SIZE;
    k2.y=11*CELL_SIZE;
    k2.sprite.setPosition(k2.x,k2.y);
    p2.x=9*CELL_SIZE;
    p2.y=11*CELL_SIZE;
    p2.sprite.setPosition(p2.x,p2.y);

    g2.x=9*CELL_SIZE;
    g2.y=10*CELL_SIZE;
    g2.xPos=9*CELL_SIZE;
    g2.yPos=10*CELL_SIZE;

    g2.sprite.setPosition(g2.x,g2.y);

    g3.x=10*CELL_SIZE;
    g3.y=11*CELL_SIZE;
    g3.xPos=10*CELL_SIZE;
    g3.yPos=11*CELL_SIZE;
    g3.sprite.setPosition(g3.x,g3.y);
    

    g4.x=11*CELL_SIZE;
    g4.y=10*CELL_SIZE;
    g4.xPos=11*CELL_SIZE;
    g4.yPos=10*CELL_SIZE;
    g4.sprite.setPosition(g4.x,g4.y);

    g2.fastghost=1;
    g4.fastghost=1; 
    
    RenderData renderData;
    renderData.window = &window;
    renderData.pacman=&pacman;
    renderData.ghost=&g1;
    renderData.ghost2=&g2;
    renderData.ghost3=&g3;
    renderData.ghost4=&g4;
    renderData.p1=&p1;
    renderData.p2=&p2;
    renderData.k1=&k1;
    renderData.k2=&k2;
    renderData.fp1=&fp1;

    //renderData->isWindowOpen = &isWindowOpen;
    pthread_t thread;
    pthread_t thread2;
    pthread_t thread3;
    pthread_t thread4;
    pthread_t thread5;
    pthread_mutex_init(&mutex, NULL);
    pthread_mutex_init(&mutex1, NULL);
    pthread_mutex_init(&phil_mutex, NULL);
    sem_init(&semaphore,0,1);
    sem_init(&semaphore2,0,1);
    sem_init(&semaphore3,0,1);
    sem_init(&semaphore4,0,1);
    bool displayscore=0;

    for (int i = 0; i < N; i++) {
        sem_init(&forks[i], 0, 1);
        //cout << "Philosopher " << i + 1 << " is thinking" << endl;
    }


    pthread_create(&thread, nullptr, &renderThread, &renderData);
    pthread_create(&thread2, nullptr, &ghost1Thread, &renderData);
    pthread_create(&thread3, nullptr, &ghost2Thread, &renderData); 
    pthread_create(&thread4, nullptr, &ghost3Thread, &renderData); 
    pthread_create(&thread5, nullptr, &ghost4Thread, &renderData); 


    FloatRect gBound;
    sf::Font scorefont;
     if (!scorefont.loadFromFile("Resources/score.ttf")) {
        std::cerr << "Failed to load font!" << std::endl;
        return -1;
    }
    Event event;
    Text scoreText;
    scoreText.setFont(scorefont); // Set the font
    scoreText.setCharacterSize(FONT_HEIGHT); // Set the character size
    scoreText.setFillColor(sf::Color::White); // Set the color
    scoreText.setPosition(10, 335); // Set the position
    sf::Texture lifeTexture;
    if (!lifeTexture.loadFromFile("Resources/life.png")) {
        std::cerr << "Failed to load life texture!" << std::endl;
        return -1;
    }
    sf::Sprite lifeSprite;
    lifeSprite.setTexture(lifeTexture);
    sprite.setScale(0.02,0.02);
    sf::SoundBuffer buffer;
        if (!buffer.loadFromFile("Resources/pacman_beginning.wav")) {
            std::cerr << "Error loading .wav file!" << std::endl;
            return -1;
        }
    sf::Sound sound;
    sound.setBuffer(buffer);
    sound.play();
    Clock clock;
    clock.restart();
    sf::Time elapsed = clock.getElapsedTime();

                // Convert elapsed time to seconds
                float seconds = elapsed.asSeconds();
    while (window.isOpen())
    {
        
        
        sf::Time elapsed = clock.getElapsedTime();

                // Convert elapsed time to seconds
        float seconds = elapsed.asSeconds();
        // Play the sound
        if (seconds>4)
        {
            sound.play();
            clock.restart();
        }
        
        while (window.pollEvent(event))
        {
            if (event.type == sf::Event::Closed)
                {
                    window.close();
                    //game=false;
                    //window2.setVisible(true);
                    checkplayerscore(username,pacman.score);
                    //*(renderData->isWindowOpen)=false;
                    ////cout<<*(renderData->isWindowOpen)<<endl;
                }
        }
        if (pacman.lives==0)
            {
                window.close();
                //game=false;
                //window2.setVisible(true);
                displayscore=1;
                checkplayerscore(username,pacman.score);

            }
        window.clear();

        window.draw(pacman.sprite);
        window.draw(g1.sprite);
        window.draw(g2.sprite);
        window.draw(g3.sprite);
        window.draw(g4.sprite);

        scoreText.setString("Score: " + std::to_string(pacman.score));
        window.draw(scoreText);
        for (int i = 0; i < pacman.lives; ++i) {
            lifeSprite.setPosition(250 + i * 30, 335); // Adjust position for each life
            window.draw(lifeSprite);
        }

        if (k1.spawn && ::key>0|| (!g1.pickup&&!g2.pickup&&!g3.pickup&&!g4.pickup))
            window.draw(k1.sprite);
        if (k2.spawn && ::key>0 || (!g1.pickup&&!g2.pickup&&!g3.pickup&&!g4.pickup))
            window.draw(k2.sprite);
        if (p1.spawn && ::key>0|| (!g1.pickup&&!g2.pickup&&!g3.pickup&&!g4.pickup))
            window.draw(p1.sprite);
        if (p2.spawn && ::key>0|| (!g1.pickup&&!g2.pickup&&!g3.pickup&&!g4.pickup))
            window.draw(p2.sprite);
        if (g2.escaped && g2.fastghost)
        {
            //cout<<"val:"<<g2.eaten<<endl;
            //cout<<"HELLLOOO"<<endl;
            if (!g2.eaten && !g4.eaten)
            {
                if (checkfastpelletcollision(g2,fp1)){
                    g2.start();
                    g2.speed=0.09;
                    g2.eaten=1;
                }
            }
            if (g2.eaten)
            {
                checkghostspeed(g2);
            }
        }
        else if (g2.house){
            g2.eaten=0;
            g2.speed=0.01;
        }
        if (g4.escaped && g4.fastghost)
        {
            //cout<<"val of:"<<g4.eaten<<endl;
            //cout<<"HELLLOOO"<<endl;
            if (!g4.eaten &&  !g2.eaten)
            {
                if (checkfastpelletcollision(g4,fp1)){
                    g4.start();
                    g4.speed=0.09;
                    g4.eaten=1;
                }
            }
            if (g4.eaten)
            {
                checkghostspeed(g4);
            }
        }
        else if (g4.house){
            g4.eaten=0;
            g4.speed=0.01;
        }
        if (totalpellets<10)
        {
            generatepellets();
        }
        if (powerpellet<1)
        {
            generatepowerpellets();
        }
        //cout<<"score:"<<pacman.score<<endl;
        draw_map(window,fp1);
        window.display();
    }

    if (displayscore) {
    Text text33;
    sf::Texture scoretex;
    sf::Sprite spritetex;
    scoretex.loadFromFile("Resources/gameover.png");
    spritetex.setTexture(scoretex);
    spritetex.setScale(0.1f, 0.1f);
    // spritetex.setPosition(0, 0);

    text33.setFont(font10);
    text33.setCharacterSize(24);
    text33.setFillColor(sf::Color::Black);
    text33.setString("YOUR TOTAL SCORE : " + to_string(pacman.score));
    text33.setPosition(250, 480);
    text33.setFillColor(Color::Black);
    sf::RenderWindow window4(sf::VideoMode(680, 680), "Player Score");

    while (window4.isOpen()) {
        sf::Event event;
        while (window4.pollEvent(event)) {
            if (event.type == sf::Event::Closed) {
                window4.close();
            }
        }
        window4.clear(sf::Color::White);
        window4.draw(spritetex); // Draw the sprite first
        window4.draw(text33);    // Then draw the text on top
        window4.display();
    }
}

    pthread_mutex_destroy(&mutex);
    sem_destroy(&semaphore);
    sem_destroy(&semaphore2);
    sem_destroy(&semaphore3);
    sem_destroy(&semaphore4);
    }
    

    ////cout<<*(renderData->isWindowOpen)<<endl;
    //pthread_join(thread, nullptr);
    //pthread_exit(NULL);

    return 0;
}